#include <iostream>
using namespace std;

int main()
{
	cout << "\n\nHI\n\n";
	cout << "Press ENTER to continue.\n";
	cin.get();  //get is a function that will retrieve ONE character from the keyboard
	cout << "\n\nGOOD BYE\n\n";
	
	return 0;
}