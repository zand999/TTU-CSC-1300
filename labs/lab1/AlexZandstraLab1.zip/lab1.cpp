/*
    File Name lab1.cpp
    Author: Alex Zandstra
    Date: 8/29/19
    Purpose My first6 C++ program!
*/
#include <iostream>
using namespace std;
int main(){
  cout << endl;
  cout << "Hello, my name is Alex. \n\n";
  cout << "This is my first lab in CSC1300!\n\n";
  return 0;


}
