/*
  Title: Driver.cpp
  Author: Alex Zandstra
  Date Started: 10/24/19
  Purpose: header file
*/


#ifndef _FUNCTIONS_H
#define _FUNCTIONS_H

#include <iostream>
using namespace std;

//#include <iomanip>
//#include <math.h>
//#include <string>

void GetElephantData(float[], string[]);
void GetStats(float[], float&, float&, int&);

#endif
